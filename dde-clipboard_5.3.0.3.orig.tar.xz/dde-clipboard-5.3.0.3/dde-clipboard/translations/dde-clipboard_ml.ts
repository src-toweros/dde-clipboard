<?xml version="1.0" ?><!DOCTYPE TS><TS language="ml" version="2.1">
<context>
    <name>ItemData</name>
    <message>
        <location filename="../itemdata.cpp" line="81"/>
        <source>Picture</source>
        <translation>ചിത്രം</translation>
    </message>
    <message>
        <location filename="../itemdata.cpp" line="83"/>
        <source>Text</source>
        <translation>ടെക്സ്റ്റ്</translation>
    </message>
    <message>
        <location filename="../itemdata.cpp" line="85"/>
        <source>File</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../itemdata.cpp" line="97"/>
        <source>%1 characters</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ItemWidget</name>
    <message>
        <location filename="../itemwidget.cpp" line="468"/>
        <source>1 minute ago</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../itemwidget.cpp" line="470"/>
        <source>%1 minutes ago</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../itemwidget.cpp" line="472"/>
        <source>1 hour ago</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../itemwidget.cpp" line="474"/>
        <source>%1 hours ago</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../itemwidget.cpp" line="460"/>
        <source>Yesterday</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../itemwidget.cpp" line="400"/>
        <source>%1 files (%2...)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../itemwidget.cpp" line="466"/>
        <source>Just now</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../itemwidget.cpp" line="553"/>
        <source>(File deleted)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="191"/>
        <source>Clipboard</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="194"/>
        <source>Clear all</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>