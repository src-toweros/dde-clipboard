<?xml version="1.0" ?><!DOCTYPE TS><TS language="en" version="2.1">
<context>
    <name>ItemData</name>
    <message>
        <location filename="../itemdata.cpp" line="81"/>
        <source>Picture</source>
        <translation>Picture</translation>
    </message>
    <message>
        <location filename="../itemdata.cpp" line="83"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../itemdata.cpp" line="85"/>
        <source>File</source>
        <translation>File</translation>
    </message>
    <message>
        <location filename="../itemdata.cpp" line="97"/>
        <source>%1 characters</source>
        <translation>%1 characters</translation>
    </message>
</context>
<context>
    <name>ItemWidget</name>
    <message>
        <location filename="../itemwidget.cpp" line="468"/>
        <source>1 minute ago</source>
        <translation>1 minute ago</translation>
    </message>
    <message>
        <location filename="../itemwidget.cpp" line="470"/>
        <source>%1 minutes ago</source>
        <translation>%1 minutes ago</translation>
    </message>
    <message>
        <location filename="../itemwidget.cpp" line="472"/>
        <source>1 hour ago</source>
        <translation>1 hour ago</translation>
    </message>
    <message>
        <location filename="../itemwidget.cpp" line="474"/>
        <source>%1 hours ago</source>
        <translation>%1 hours ago</translation>
    </message>
    <message>
        <location filename="../itemwidget.cpp" line="460"/>
        <source>Yesterday</source>
        <translation>Yesterday</translation>
    </message>
    <message>
        <location filename="../itemwidget.cpp" line="400"/>
        <source>%1 files (%2...)</source>
        <translation>%1 files (%2...)</translation>
    </message>
    <message>
        <location filename="../itemwidget.cpp" line="466"/>
        <source>Just now</source>
        <translation>Just now</translation>
    </message>
    <message>
        <location filename="../itemwidget.cpp" line="553"/>
        <source>(File deleted)</source>
        <translation>(File deleted)</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="191"/>
        <source>Clipboard</source>
        <translation>Clipboard</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="194"/>
        <source>Clear all</source>
        <translation>Clear all</translation>
    </message>
</context>
</TS>